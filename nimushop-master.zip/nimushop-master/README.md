# Nimushop
###### Light-weight e-commerce web site design

![Image of homeage of this repository](https://github.com/nasim-007/nimushop/blob/master/nimushop.png)

### How to run
Clone or download this repository and open index.html with a browser. Let's see magic! It's totally static no back-end.

### What you learn from this source code?

- [x] E-commerce website structure
- [x] Advance javascripts funstions
- [x] Cart page design
- [x] Multipage design
- [x] Contact page
- [x] Checkout page
- [x] Product page
- [x] Category page
- [ ] Javascripts framework
- [x] More css classes
- [x] Responsive designs
- [x] Tab items
- [ ] Pdf viewer and downloads
- [x] Smooth schrolling
- [ ] Article side items nevigate
- [ ] Javascripts back-end

###### Feel free to contact

```Contact
   Email:nasim.mahmud.1996@gmail.com
   Phone: 01777-424142
```
